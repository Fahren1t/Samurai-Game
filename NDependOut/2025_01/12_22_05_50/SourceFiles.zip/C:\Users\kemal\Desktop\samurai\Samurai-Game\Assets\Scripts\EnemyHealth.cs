using UnityEngine;

public class EnemyHealth : Health, IDamageable
{
    
}
