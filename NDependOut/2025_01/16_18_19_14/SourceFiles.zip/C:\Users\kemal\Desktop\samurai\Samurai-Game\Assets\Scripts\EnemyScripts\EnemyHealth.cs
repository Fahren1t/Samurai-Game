using Game.Scripts;

namespace Game.EnemyScripts
{
    public class EnemyHealth : Health
    {

    }
}