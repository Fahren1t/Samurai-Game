using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEngine;

public class AttackArea : MonoBehaviour
{
    private readonly int damage = 1;

    private EnemyHealth health;
    
    private readonly bool canDeflect = false;  // Add this variable to track deflectable objects
    private readonly GameObject currentDeflectableObject = null;  // To store the reference to deflectable object

    public event Action<IDeflectable> OnDeflectableEntered; // Event to notify deflectable objects

    public void OnTriggerEnter2D(Collider2D collider)
    {
        //check the health condition
        if (collider.GetComponent<EnemyHealth>() != null)
        {
            health = collider.GetComponent<EnemyHealth>();
            health.Damage(damage);
        }
        
        // Check for IDeflectable interface
        if (collider.TryGetComponent<IDeflectable>(out var deflectable))
        {
            Debug.Log("Deflectable object entered");
            OnDeflectableEntered?.Invoke(deflectable); // Notify the playerAtack script
        
        }
       /*
        // Check for IDeflectable interface
        IDeflectable deflectable = collider.GetComponent<IDeflectable>();
        if (deflectable != null)
        {
            canDeflect = true;
            currentDeflectableObject = collider.gameObject;

            Debug.Log(" object entered");

            // Reset deflectable status when object exits the trigger
            canDeflect = false;
            currentDeflectableObject = null;
        }
       */

    }
    // Getter method to get the current deflectable object
    public bool CanDeflect() => canDeflect;

    public IDeflectable GetDeflectableObject()
    {
        return currentDeflectableObject != null
            ? currentDeflectableObject.GetComponent<IDeflectable>() : null;
    } 
    
}