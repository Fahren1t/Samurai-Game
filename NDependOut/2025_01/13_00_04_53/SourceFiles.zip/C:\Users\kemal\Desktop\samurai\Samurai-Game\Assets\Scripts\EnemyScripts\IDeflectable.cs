using UnityEngine;

namespace Game.Enemies
{
    public interface IDeflectable
    {
        public void Deflect(Vector2 direction);

        public float ReturnSpeed { get; set; }
    }
}