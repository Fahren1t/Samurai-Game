using Game.Common;


    public class EnemyHealth : Health
    {

    }
