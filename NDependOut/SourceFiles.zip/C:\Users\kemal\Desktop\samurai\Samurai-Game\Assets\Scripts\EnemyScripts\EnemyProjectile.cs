using Game.Scripts;
using UnityEngine;

namespace Game.EnemyScripts
{
    public class EnemyProjectile : MonoBehaviour, IDeflectable
    {
        [field: SerializeField] public float ReturnSpeed { get; set; } = 130f; //return speed of bullet after it has been deflected
                                public Collider2D enemyColl { get; set; } //gets the enemy collider

               [SerializeField] public int damageAmount = 5; //damage of particle

                                
                                private Collider2D coll; //gets the bullet collider

                                private IDamageable iDamagable;

                                private Rigidbody2D rb; //rigidbody of particle
    

        private void Start()
        {

            coll = GetComponent<Collider2D>(); //get collider of projectile
            rb = GetComponent<Rigidbody2D>(); //get ridgidbody of projectile

            //before starting, set the collison false so that enemy doesn't hurt himself
            IgnoreCollisionWithEnemyToggle();

            //destroy the arrow after 3 seconds
            Destroy(gameObject, 3);
        }

        //ignores the collision between enemy and projectile
        private void IgnoreCollisionWithEnemyToggle()
        {

            if (!Physics2D.GetIgnoreCollision(coll, enemyColl))
            {
                //turn on ignore collisions
                Physics2D.IgnoreCollision(coll, enemyColl, true);
            }

            else
            {
                //turn off ignore collision
                Physics2D.IgnoreCollision(coll, enemyColl, false);
            }

        }

        //deflect the particle
        public void Deflect(Vector2 deflectionDirection)
        {
            IgnoreCollisionWithEnemyToggle();
            // Instantly redirect with high force
            rb.linearVelocity = Vector2.zero; // Reset velocity
            rb.AddForce(deflectionDirection * ReturnSpeed, ForceMode2D.Impulse); // Apply force in the new direction

            // Flip the object horizontally to face the opposite direction
            transform.rotation = Quaternion.Euler(0, 0, transform.rotation.eulerAngles.z + 180f);


        }
    }
}