namespace Game.Scripts
{
    public interface IDamageable
    {
        public void Damage(int damageAmount);
    }
}